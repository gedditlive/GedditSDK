//
//  CoreSDK.h
//  CoreSDK
//
//  Created by Andrei Solovev on 23/12/19.
//  Copyright © 2019 Geddit. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for CoreSDK.
FOUNDATION_EXPORT double CoreSDKVersionNumber;

//! Project version string for CoreSDK.
FOUNDATION_EXPORT const unsigned char CoreSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CoreSDK/PublicHeader.h>


