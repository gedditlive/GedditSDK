# Changelog

All notable changes to this project will be documented in this file.
  
The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## 1.2.1 - 2020/06/10

- Fixed: Bitcode compilation support.

## 1.2.0 - 2020/05/20

- Added: `collection_id` and `collection_name` properties for `product_category_update` event.
- Added: `collection_id` and `collection_name` properties for `like` event.
- Added: `collection_id` and `collection_name` properties for `dismiss_product_list` event.
- Added: `collection_id` and `collection_name` properties for `product_image_pressed` event.
- Added: `collection_id` and `collection_name` properties for `display_product_list` event.
- Added: `collection_id` and `collection_name` properties for `send_chat_message` event.
- Added: `collection_id` and `collection_name` properties for `share` event.
- Added: `show_id` property for `live_screen_tap` event.
- Added: `entrypoint_id` property for `open_app` event.
- Added: `close_sdk` event.
- Added: `add_to_bag` event.
- Removed: `full_screen` property for `display_chat` event.

## 1.1.0 - 2020/05/05

- Added: Pin message feature.

## 1.0.15 - 2020/04/20

- Changed: Match the like button color to Pomelo theme color.

## 1.0.14 - 2020/03/31

- Added: Track show id value for session event
- Added: Support new event tracking API 
