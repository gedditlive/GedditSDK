//
//  GedditCommerceSDK.h
//  GedditCommerceSDK
//
//  Created by Andrei Solovev on 27/12/19.
//  Copyright © 2019 Geddit. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for GedditCommerceSDK.
FOUNDATION_EXPORT double GedditCommerceSDKVersionNumber;

//! Project version string for GedditCommerceSDK.
FOUNDATION_EXPORT const unsigned char GedditCommerceSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <GedditCommerceSDK/PublicHeader.h>


