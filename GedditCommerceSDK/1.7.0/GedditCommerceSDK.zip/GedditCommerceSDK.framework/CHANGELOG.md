# Changelog

All notable changes to this project will be documented in this file.
  
The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## 1.7.0 - 2021/01/20

- Added: List show voucher.
- Changed: Callback voucher delegate only when user collect a voucher.
- Changed: Voucher popup UI.

## 1.6.0 - 2021/01/07

- Changed: Question user interface and experience to match with Pomelo requirements.
- Changed: Live stream user interface to match with Pomelo requirements.
- Changed: Update font style to Circular.
- Added: Callback when a user answer a question and collect a voucher.

## 1.5.0 - 2020/10/30

- Added: Display voucher when user won a voucher.
- Added: Subscribe to winning voucher event. 
- Added: Callback SDK client when user won a voucher.

## 1.4.0 - 2020/10/21

- Added: New Pomelo UI.

## 1.3.1 - 2020/09/30

- Added: Xcode 12 support.

## 1.3.0 - 2020/08/26

- Added: Trivia into commerce feature.

## 1.2.2 - 2020/08/13

- Added: Swift 5.2 support.

## 1.2.1 - 2020/06/10

- Added: Bitcode compilation support.

## 1.2.0 - 2020/05/20

- Added: `collection_id` and `collection_name` properties for `product_category_update` event.
- Added: `collection_id` and `collection_name` properties for `like` event.
- Added: `collection_id` and `collection_name` properties for `dismiss_product_list` event.
- Added: `collection_id` and `collection_name` properties for `product_image_pressed` event.
- Added: `collection_id` and `collection_name` properties for `display_product_list` event.
- Added: `collection_id` and `collection_name` properties for `send_chat_message` event.
- Added: `collection_id` and `collection_name` properties for `share` event.
- Added: `show_id` property for `live_screen_tap` event.
- Added: `entrypoint_id` property for `open_app` event.
- Added: `close_sdk` event.
- Added: `add_to_bag` event.
- Removed: `full_screen` property for `display_chat` event.

## 1.1.0 - 2020/05/05

- Added: Pin message feature.

## 1.0.15 - 2020/04/20

- Changed: Match the like button color to Pomelo theme color.

## 1.0.14 - 2020/03/31

- Added: Track show id value for session event
- Added: Support new event tracking API 
