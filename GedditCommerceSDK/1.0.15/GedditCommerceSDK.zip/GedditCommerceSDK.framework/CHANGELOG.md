# Changelog

  All notable changes to this project will be documented in this file.
  
  The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
  and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.15] - 2020/04/20

- Changed: Match the like button color to Pomelo theme color.

## [1.0.14] - 2020/03/31

- Added: Track show id value for session event
- Added: Support new event tracking API 
